package com.example.fj_hotel_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FjHotelBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FjHotelBackendApplication.class, args);
	}

}
